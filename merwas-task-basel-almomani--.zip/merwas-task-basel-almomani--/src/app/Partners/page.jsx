export default function Partners() {
    return (
        <div>
            <h1>This for Partners Page</h1>
        </div>
    )
}