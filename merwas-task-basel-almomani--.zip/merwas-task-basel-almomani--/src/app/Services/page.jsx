export default function Services() {
    return (
        <div>
            <h1>This for Services Page</h1>
        </div>
    )
}