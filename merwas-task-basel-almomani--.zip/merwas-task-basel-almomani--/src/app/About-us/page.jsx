export default function AboutUs() {
    return (
        <div>
            <h1>This for About Us Page</h1>
        </div>
    )
}