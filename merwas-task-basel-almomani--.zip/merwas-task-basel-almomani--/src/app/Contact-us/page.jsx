export default function ContactUs() {
    return (
        <div>
            <h1>This for Contact Us Page</h1>
        </div>
    )
}